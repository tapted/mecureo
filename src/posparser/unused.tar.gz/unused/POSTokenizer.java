package posparser;

import opennlp.common.preprocess.*;
import opennlp.common.xml.*;

import org.jdom.*;

import java.io.*;
import java.lang.*;
import java.util.*;

public class POSTokenizer implements Pipelink {

    public static void dumpElement(Element e, String indent) {
	System.out.println(indent + e.getName() + ": \"" + 
			   e.getTextNormalize() + "\" = " +
			   e.getContent());
	for (Iterator it = e.getChildren().iterator(); it.hasNext(); ) {
	    dumpElement((Element)it.next(), indent + "  ");
	}
    }

    // play around with this method to experiment with manipulating the
    // content of an NLPDocument
    public void process (NLPDocument doc) {
//	for (Iterator sentIt=doc.sentenceIterator(); sentIt.hasNext();) {
//	    Element sentEl = (Element)sentIt.next();
	    for (Iterator tokIt=doc.tokenIterator(); tokIt.hasNext();) {
		Element tokEl = (Element)tokIt.next();
		dumpElement(tokEl, "");
		//System.out.println(tokEl);
	    }
//	}
    }

    
    public Set requires() {
        return Collections.EMPTY_SET;
    }    

}
